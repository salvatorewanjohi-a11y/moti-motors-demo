<?php
/**
 * MOTi Moto-Rs child theme: verified used cars in Lavington, with financing, trade-ins and reservations.
 */

const MM_WHATSAPP  = '254110266955';
const MM_PHONE     = '0110 266 955';
const MM_TEL       = '+254110266955';
const MM_INSTAGRAM = 'https://www.instagram.com/moti_moto_rs/';
const MM_HANDLE    = '@moti_moto_rs';
const MM_HOURS     = 'Monday – Saturday, 8:00 AM – 6:00 PM'; // PLACEHOLDER: not on their profile, to confirm.
const MM_FONTS     = 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,600;0,700;0,800;1,700&family=Inter:wght@400;500;600;700&display=swap';
const MM_FILTERS   = [ 'fuel' => 'Fuel', 'transmission' => 'Gearbox', 'drive' => 'Drive' ];

// Finance estimate. PLACEHOLDER rate: the bank or financier sets the real one.
const MM_FINANCE_RATE  = 14;
const MM_FINANCE_TERMS = [ 12, 24, 36, 48, 60 ];
const MM_MIN_DEPOSIT   = 20;
// The "From KSh …/mo" line on every car: the smallest deposit over this many months.
const MM_CARD_MONTHS = 48;

const MM_BUDGETS = [ [ 'Under 700K', 0, 700000 ], [ '700K – 1M', 700000, 1000000 ], [ '1M – 1.5M', 1000000, 1500000 ], [ '1.5M – 2.5M', 1500000, 2500000 ], [ '2.5M +', 2500000, 0 ] ];
const MM_YEARS   = [ 2015 => '2015 & newer', 2010 => '2010 & newer', 2005 => '2005 & newer' ];
const MM_BODIES  = [
	'suv'     => [ 'SUVs & crossovers', 'Forester, CX-5, Harrier, X-Trail, Touareg' ],
	'saloon'  => [ 'Saloons & estates', 'C-Class, E-Class, Crown, Mark X, Legacy' ],
	'hatch'   => [ 'Hatchbacks', 'Demio, Fit, Note, Golf, Polo, A 180' ],
	'utility' => [ 'Pickups & MPVs', 'Hilux double cab, Vellfire' ],
];
const MM_MAKES = [ 'Toyota', 'Mazda', 'Subaru', 'Nissan', 'Honda', 'Mitsubishi', 'Mercedes-Benz', 'BMW', 'Audi', 'Volkswagen', 'Land Rover', 'Other' ];
const MM_SLOTS = [ '9:00 AM', '10:30 AM', '12:00 PM', '2:00 PM', '3:30 PM', '5:00 PM' ];

const MM_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';
const MM_HEART   = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
const MM_SCALE   = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M12 4v16M5 20h14M12 6l-7 2m7-2 7 2M5 8l-3 7a3 3 0 0 0 6 0Zm14 0-3 7a3 3 0 0 0 6 0Z"/></svg>';
const MM_TICK    = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" d="m5 12 5 5 9-10"/></svg>';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'mm-fonts', MM_FONTS, [], null );
	wp_enqueue_style( 'mm', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'mm', $uri . '/assets/mm.js', [], filemtime( $dir . '/assets/mm.js' ), true );
	wp_localize_script( 'mm', 'MM', [
		'store'   => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'api'     => esc_url_raw( home_url( '/?rest_route=/mm/v1/' ) ),
		'shop'    => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'    => esc_url_raw( home_url( '/' ) ),
		'compare' => esc_url_raw( home_url( '/compare/' ) ),
		'wa'      => MM_WHATSAPP,
		'rate'    => MM_FINANCE_RATE,
		'minDep'  => MM_MIN_DEPOSIT,
		'months'  => MM_CARD_MONTHS,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'mm-fonts', MM_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

function mm_wa_link( $text = '' ) {
	return 'https://wa.me/' . MM_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}
function mm_ksh( $n ) {
	return 'KSh ' . number_format( (float) $n );
}

// Monthly repayment on a reducing balance.
function mm_monthly( $loan, $months, $rate = MM_FINANCE_RATE ) {
	$r = $rate / 1200;
	return $r ? $loan * $r / ( 1 - pow( 1 + $r, -$months ) ) : $loan / $months;
}
// The lowest monthly figure: smallest deposit, MM_CARD_MONTHS months.
function mm_from_monthly( $price ) {
	return (int) ( ceil( mm_monthly( $price * ( 1 - MM_MIN_DEPOSIT / 100 ), MM_CARD_MONTHS ) / 100 ) * 100 );
}
function mm_from_line( $price ) {
	return $price ? '<span class="mm-from" title="' . esc_attr( MM_MIN_DEPOSIT . '% deposit over ' . MM_CARD_MONTHS . ' months, an illustration at ' . MM_FINANCE_RATE . '% a year' ) . '">From <strong>' . esc_html( mm_ksh( mm_from_monthly( $price ) ) ) . '</strong>/mo</span>' : '';
}

/**
 * Specs as label => value pairs, from the "Label: value" lines staff type on the product screen.
 */
function mm_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_mm_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}
function mm_arrived( $product_id ) {
	return get_post_meta( $product_id, '_mm_arrived', true ) === 'yes';
}
function mm_ready( $product_id ) {
	return get_post_meta( $product_id, '_mm_ready', true ) === 'yes';
}
// Stock ID shown on the car and sent in every WhatsApp enquiry (the product SKU, e.g. MM114).
function mm_stock_id( $product ) {
	return $product->get_sku() ?: 'MM' . $product->get_id();
}
function mm_enquiry_text( $product ) {
	return 'Hi Moti Moto-Rs, I\'m interested in the ' . $product->get_name() . ' (' . mm_ksh( $product->get_price() ) . '), stock ID ' . mm_stock_id( $product ) . '. Is it still available? ' . $product->get_permalink();
}

/* -------------------------------------------------------------------------
 * Car page
 * ---------------------------------------------------------------------- */

// Chips, the monthly figure and the six numbers buyers ask first, above the reserve button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id    = $product->get_id();
	$chips = '<span class="mm-chip mm-chip--ok">' . MM_TICK . 'Clean • Verified</span>';
	if ( mm_arrived( $id ) ) {
		$chips .= '<span class="mm-chip mm-chip--new">Just in</span>';
	}
	if ( mm_ready( $id ) ) {
		$chips .= '<span class="mm-chip">Ready transfer</span>';
	}
	$chips .= '<span class="mm-chip mm-chip--id">Stock ID ' . esc_html( mm_stock_id( $product ) ) . '</span>';
	echo '<div class="mm-chips">' . $chips . '</div>'; // phpcs:ignore -- escaped above.
	if ( $product->is_in_stock() ) {
		echo '<p class="mm-from-lg">' . mm_from_line( (float) $product->get_price() ) . ' <a href="#finance">Work out yours ↓</a></p>'; // phpcs:ignore
	}
	$specs = mm_specs( $id );
	$keys  = array_filter( [
		'Year'    => $specs['Year of manufacture'] ?? '',
		'Engine'  => $specs['Engine'] ?? '',
		'Fuel'    => $specs['Fuel'] ?? '',
		'Gearbox' => $specs['Transmission'] ?? '',
		'Drive'   => $specs['Drive'] ?? '',
		'Body'    => $specs['Body'] ?? '',
	], fn( $v ) => $v !== '' );
	if ( $keys ) {
		echo '<ul class="mm-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Reserve this car' );
add_filter( 'woocommerce_product_add_to_cart_text', fn( $text, $product ) => $product->is_in_stock() ? 'View car' : 'Reserved', 10, 2 );

// WhatsApp, test drive, trade-in, compare and share, the finance estimate and the promise, under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id   = $product->get_id();
	$name = $product->get_name();
	echo '<div class="mm-actions">';
	echo '<a class="mm-wa-order" href="' . esc_url( mm_wa_link( mm_enquiry_text( $product ) ) ) . '" target="_blank" rel="noopener">' . MM_WA_ICON . 'Chat with sales on WhatsApp</a>';
	if ( $product->is_in_stock() ) {
		echo '<button type="button" class="mm-ghost" data-mm-testdrive="' . esc_attr( $name ) . '" data-url="' . esc_url( $product->get_permalink() ) . '">Book a test drive</button>';
		echo '<button type="button" class="mm-ghost" data-mm-tradein="' . esc_attr( $name ) . '" data-price="' . esc_attr( (float) $product->get_price() ) . '">Trade in my car for this</button>';
	}
	echo '<div class="mm-actions__row"><button type="button" class="mm-link-btn" data-mm-compare="' . $id . '" aria-pressed="false">' . MM_SCALE . '<span>Compare</span></button><button type="button" class="mm-link-btn" data-mm-wish="' . $id . '" aria-pressed="false">' . MM_HEART . '<span>Save</span></button><button type="button" class="mm-link-btn" data-mm-copy="' . esc_url( $product->get_permalink() ) . '"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg><span>Copy link</span></button>';
	$ig = get_post_meta( $id, '_mm_ig', true );
	if ( $ig ) {
		echo '<a class="mm-link-btn" href="' . esc_url( $ig ) . '" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M8 5v14l11-7z"/></svg><span>Walk-around video</span></a>';
	}
	echo '</div></div>';

	if ( $product->is_in_stock() ) {
		echo mm_finance_box( (float) $product->get_price(), true ); // phpcs:ignore -- built from escaped parts.
	}

	echo '<ul class="mm-promise"><li><span aria-hidden="true">' . MM_TICK . '</span><p><strong>Clean • Verified</strong>Every car is walked round on video before it\'s listed. View it, drive it and bring your mechanic before you pay a shilling.</p></li><li><span aria-hidden="true">⇄</span><p><strong>Trade-in accepted</strong>Bring your current car as part of the deposit. We value it and you top up the difference.</p></li><li><span aria-hidden="true">✎</span><p><strong>Paperwork handled</strong>Sale agreement and NTSA logbook transfer done with you, so you drive away in your own name.</p></li></ul>';
} );

// The finance estimate (also used on its own on the home page).
function mm_finance_box( $price = 0, $on_car = false ) {
	$terms = '';
	foreach ( MM_FINANCE_TERMS as $t ) {
		$terms .= '<label class="mm-term"><input type="radio" name="mm_term" value="' . $t . '"' . ( $t === 48 ? ' checked' : '' ) . '><span>' . $t . '</span></label>';
	}
	$price_field = $on_car ? '' : '<label class="mm-fin__price">Car price<span class="mm-fin__input"><em>KSh</em><input type="text" inputmode="numeric" data-mm-fin-price value="' . esc_attr( number_format( $price ) ) . '" aria-label="Car price in shillings"></span></label>';
	return '<div class="mm-fin"' . ( $on_car ? ' id="finance"' : '' ) . ' data-mm-finance data-price="' . esc_attr( $price ) . '"' . ( $on_car ? ' data-on-car' : '' ) . '>'
		. '<p class="mm-fin__title">Asset financing calculator</p>'
		. $price_field
		. '<label class="mm-fin__dep">Deposit <output data-mm-fin-dep-pct>30%</output><input type="range" min="' . MM_MIN_DEPOSIT . '" max="80" step="5" value="30" data-mm-fin-dep aria-label="Deposit percentage"><small data-mm-fin-dep-ksh></small></label>'
		. '<fieldset class="mm-fin__terms"><legend>Repayment period (months)</legend><div class="mm-fin__termrow">' . $terms . '</div></fieldset>'
		. '<label class="mm-fin__rate">Interest rate <span><input type="number" min="5" max="30" step="0.5" value="' . MM_FINANCE_RATE . '" data-mm-fin-rate aria-label="Interest rate, percent a year"><em>% a year</em></span></label>'
		. '<div class="mm-fin__out"><p>About <strong data-mm-fin-monthly>–</strong><span>a month</span></p><dl><dt>Loan</dt><dd data-mm-fin-loan>–</dd><dt>Interest</dt><dd data-mm-fin-interest>–</dd></dl></div>'
		. '<p class="mm-fin__note">An illustration on a reducing balance. The bank or asset financier sets the real rate and terms; we help you apply and handle the paperwork.</p>'
		. '<div class="mm-fin__ctas"><button type="button" class="wp-element-button mm-fin__apply" data-mm-fin-apply>Get pre-approved</button><button type="button" class="mm-fin__wa" data-mm-fin-wa>' . MM_WA_ICON . 'Ask on WhatsApp</button></div>'
		. '</div>';
}

// The cars are one of a kind: one in stock, one per order.
add_filter( 'woocommerce_is_sold_individually', '__return_true' );

// A reserved car (stock 0) says so; staff unpublish it once it's sold.
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? $text : 'Reserved by another buyer. WhatsApp us to go on the waiting list, or tell us what you want and we\'ll find one like it.', 10, 2 );

// Overview, specifications, buying & paperwork.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$specs = mm_specs( $product->get_id() );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title']    = 'Overview';
		$tabs['description']['priority'] = 1;
	}
	if ( $specs ) {
		$tabs['mm_specs'] = [
			'title'    => 'Spec sheet',
			'priority' => 5,
			'callback' => function () use ( $specs, $product ) {
				echo '<table class="mm-spec-table"><tbody><tr><th>Stock ID</th><td>' . esc_html( mm_stock_id( $product ) ) . '</td></tr>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			},
		];
	}
	$tabs['mm_buying'] = [
		'title'    => 'Cash, finance & trade-in',
		'priority' => 30,
		'callback' => function () {
			echo '<div class="mm-ways"><div><h4>Cash</h4><p>Agree the price, sign the sale agreement, pay by bank transfer and drive away. We do the NTSA logbook transfer with you.</p></div><div><h4>Finance</h4><p>Put down a deposit (from ' . MM_MIN_DEPOSIT . '%) and repay monthly through a bank or asset financier. We send your documents and follow up the approval.</p></div><div><h4>Trade-in</h4><p>Bring your current car. We value it, it counts towards the price, and you top up the difference in cash or with finance.</p></div></div>';
			echo '<ol class="mm-steps-list"><li><strong>Reserve or enquire.</strong> Reserve online (nothing to pay) or message us on WhatsApp. We hold the car while you arrange a viewing.</li><li><strong>View, test drive, inspect.</strong> See it in person, drive it, and bring your own mechanic.</li><li><strong>Pay your way.</strong> Cash, financing or a trade-in plus top-up.</li><li><strong>Paperwork.</strong> Sale agreement and NTSA logbook transfer into your name.</li><li><strong>Drive your dream home.</strong></li></ol>';
		},
	];
	unset( $tabs['additional_information'], $tabs['reviews'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Car cards
 * ---------------------------------------------------------------------- */

function mm_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Second photo on hover, ribbons, verified tag, saved-car heart, compare and quick view.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = mm_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$id      = $product->get_id();
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'mm-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$extra = '';
	if ( ! $product->is_in_stock() ) {
		$extra .= '<span class="mm-ribbon mm-ribbon--sold">Reserved</span>';
	} elseif ( mm_arrived( $id ) ) {
		$extra .= '<span class="mm-ribbon">Just in</span>';
	}
	$extra .= '<span class="mm-tag">' . MM_TICK . 'Clean • Verified</span>';
	$extra .= sprintf(
		'<div class="mm-card-tools"><button type="button" class="mm-heart" data-mm-wish="%1$d" aria-label="Save %2$s" aria-pressed="false">%3$s</button><button type="button" class="mm-cmp" data-mm-compare="%1$d" aria-label="Compare %2$s" aria-pressed="false">%4$s</button></div><button type="button" class="mm-qv-btn" data-mm-qv="%1$d" data-badge="%5$s" data-stock="%6$s" aria-label="Quick view of %2$s">Quick view</button>',
		$id,
		esc_attr( $product->get_name() ),
		MM_HEART,
		MM_SCALE,
		esc_attr( get_post_meta( $id, '_mm_spec', true ) ),
		esc_attr( mm_stock_id( $product ) )
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Engine, fuel and gearbox above the price; the monthly figure under it.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = mm_card_product( $instance );
	if ( ! $product || is_singular( 'product' ) && empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$spec = get_post_meta( $product->get_id(), '_mm_spec', true );
	$line = $spec ? '<p class="mm-specline">' . implode( '', array_map( fn( $p ) => '<span>' . esc_html( $p ) . '</span>', explode( ' · ', $spec ) ) ) . '</p>' : '';
	return $line . '<div class="mm-pricebox">' . $content . ( $product->is_in_stock() ? mm_from_line( (float) $product->get_price() ) : '' ) . '</div>';
}, 10, 3 );

// "View car", test drive and a WhatsApp shortcut instead of an add-to-cart button: a car is chosen on its page.
add_filter( 'render_block_woocommerce/product-button', function ( $content, $block, $instance ) {
	$product = mm_card_product( $instance );
	if ( ! $product ) {
		return $content;
	}
	$td = $product->is_in_stock() ? '<button type="button" class="mm-card-td" data-mm-testdrive="' . esc_attr( $product->get_name() ) . '" data-url="' . esc_url( $product->get_permalink() ) . '">Test drive</button>' : '';
	return '<div class="mm-card-actions"><a class="mm-card-view" href="' . esc_url( $product->get_permalink() ) . '">' . ( $product->is_in_stock() ? 'View car' : 'Reserved · details' ) . '</a>' . $td . '<a class="mm-card-wa" href="' . esc_url( mm_wa_link( mm_enquiry_text( $product ) ) ) . '" target="_blank" rel="noopener" aria-label="Ask about the ' . esc_attr( $product->get_name() ) . ' on WhatsApp">' . MM_WA_ICON . '</a></div>';
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function mm_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}
function mm_brands() {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// The card used by the shortcode grids (the templates carry the same blocks).
const MM_CARD = '<!-- wp:woocommerce/product-template -->
<!-- wp:woocommerce/product-image {"showSaleBadge":false,"isDescendentOfQueryLoop":true,"aspectRatio":"4/5","scale":"cover"} /-->
<!-- wp:post-title {"level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0.3rem","top":"0.9rem"}}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->
<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /-->
<!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true} /-->
<!-- /wp:woocommerce/product-template -->';

// A row of car cards, e.g. [mm_collection cat="suv" limit="8"] or [mm_collection featured="1"].
add_shortcode( 'mm_collection', function ( $atts ) {
	$atts = shortcode_atts( [ 'cat' => '', 'brand' => '', 'featured' => '', 'limit' => 8, 'columns' => 4 ], $atts );
	$tax  = [];
	if ( $atts['cat'] ) {
		$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
		if ( ! $term ) {
			return '';
		}
		$tax['product_cat'] = [ $term->term_id ];
	}
	if ( $atts['brand'] && taxonomy_exists( 'product_brand' ) ) {
		$term = get_term_by( 'slug', $atts['brand'], 'product_brand' );
		if ( $term ) {
			$tax['product_brand'] = [ $term->term_id ];
		}
	}
	static $qid = 40;
	$query = [
		'perPage' => (int) $atts['limit'], 'pages' => 1, 'offset' => 0, 'postType' => 'product', 'order' => 'asc', 'orderBy' => 'menu_order',
		'search' => '', 'exclude' => [], 'inherit' => false, 'taxQuery' => $tax ?: (object) [], 'isProductCollectionBlock' => true,
		'featured' => (bool) $atts['featured'], 'woocommerceOnSale' => false, 'woocommerceStockStatus' => [ 'instock', 'outofstock', 'onbackorder' ], 'woocommerceAttributes' => [], 'woocommerceHandPickedProducts' => [],
	];
	$attrs = [ 'queryId' => $qid++, 'query' => $query, 'tagName' => 'div', 'displayLayout' => [ 'type' => 'flex', 'columns' => (int) $atts['columns'], 'shrinkColumns' => true ], 'dimensions' => [ 'widthType' => 'fill' ], 'queryContextIncludes' => [ 'collection' ] ];
	return do_blocks( '<!-- wp:woocommerce/product-collection ' . wp_json_encode( $attrs ) . ' --><div class="wp-block-woocommerce-product-collection">' . MM_CARD . '</div><!-- /wp:woocommerce/product-collection -->' );
} );

// Search & filter hub in the hero: make, body, year and a budget as a cash price or a monthly figure.
add_shortcode( 'mm_finder', function () {
	$makes = '';
	foreach ( mm_brands() as $t ) {
		$makes .= '<option value="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . ' (' . (int) $t->count . ')</option>';
	}
	$bodies = '';
	foreach ( mm_categories() as $t ) {
		$bodies .= '<option value="' . esc_attr( $t->slug ) . '" data-url="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</option>';
	}
	$cash = '';
	foreach ( [ 600000, 800000, 1000000, 1500000, 2000000, 3000000 ] as $b ) {
		$cash .= '<option value="' . $b . '">Up to ' . esc_html( mm_ksh( $b ) ) . '</option>';
	}
	$monthly = '';
	foreach ( [ 15000, 20000, 30000, 45000, 60000, 80000 ] as $m ) {
		$monthly .= '<option value="' . $m . '">Up to ' . esc_html( mm_ksh( $m ) ) . ' a month</option>';
	}
	$years = '';
	foreach ( MM_YEARS as $y => $label ) {
		$years .= '<option value="' . $y . '">' . esc_html( $label ) . '</option>';
	}
	$count = (int) ( wp_count_posts( 'product' )->publish ?? 0 );
	return '<form class="mm-finder" data-mm-finder action="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">'
		. '<div class="mm-finder__head"><p class="mm-finder__title">Find your car</p><div class="mm-toggle" role="radiogroup" aria-label="How you\'ll pay"><label><input type="radio" name="pay" value="cash" checked><span>Cash price</span></label><label><input type="radio" name="pay" value="monthly"><span>Monthly</span></label></div></div>'
		. '<div class="mm-finder__grid">'
		. '<label>Make<select name="make"><option value="">Any make</option>' . $makes . '</select></label>'
		. '<label>Body type<select name="body"><option value="">Any body type</option>' . $bodies . '</select></label>'
		. '<label>Year<select name="min_year"><option value="">Any year</option>' . $years . '</select></label>'
		. '<label data-mm-budget="cash">Budget<select name="max_price"><option value="">Any budget</option>' . $cash . '</select></label>'
		. '<label data-mm-budget="monthly" hidden>Monthly budget<select name="max_monthly"><option value="">Any monthly</option>' . $monthly . '</select></label>'
		. '</div>'
		. '<button class="wp-element-button" type="submit">Show ' . $count . ' verified cars</button>'
		. '<p class="mm-finder__note" data-mm-budget="monthly" hidden>With a ' . MM_MIN_DEPOSIT . '% deposit over ' . MM_CARD_MONTHS . ' months. Trade-ins count towards the deposit.</p>'
		. '</form>';
} );

// Makes in stock, each with how many cars.
add_shortcode( 'mm_makes', function () {
	$h = '<div class="mm-makes">';
	foreach ( mm_brands() as $t ) {
		$h .= sprintf( '<a class="mm-make" href="%s"><strong>%s</strong><span>%s</span></a>', esc_url( get_term_link( $t ) ), esc_html( $t->name ), esc_html( sprintf( _n( '%d car', '%d cars', $t->count ), $t->count ) ) );
	}
	return $h . '<a class="mm-make mm-make--all" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '"><strong>All cars</strong><span>Browse everything →</span></a></div>';
} );

// Body types as photo tiles.
add_shortcode( 'mm_bodies', function () {
	$h = '<div class="mm-bodies">';
	foreach ( MM_BODIES as $slug => [ $title, $line ] ) {
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( ! $term || ! $term->count ) {
			continue;
		}
		$first = wc_get_products( [ 'limit' => 1, 'status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC', 'category' => [ $slug ], 'stock_status' => 'instock' ] );
		$img   = $first ? $first[0]->get_image( 'woocommerce_single', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h    .= sprintf( '<a class="mm-body" href="%s">%s<span><em>%s</em><strong>%s</strong><small>%s</small></span></a>', esc_url( get_term_link( $term ) ), $img, esc_html( sprintf( _n( '%d car', '%d cars', $term->count ), $term->count ) ), esc_html( $title ), esc_html( $line ) );
	}
	return $h . '</div>';
} );

// Stand-alone finance calculator for the home page.
add_shortcode( 'mm_finance', fn() => mm_finance_box( 1500000 ) );

// The most-watched walk-around reels, with their real view counts.
add_shortcode( 'mm_reels', function () {
	$ids = get_posts( [ 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 6, 'fields' => 'ids', 'meta_key' => '_mm_views', 'orderby' => 'meta_value_num', 'order' => 'DESC' ] );
	$h   = '<div class="mm-reels">';
	foreach ( $ids as $id ) {
		$p     = wc_get_product( $id );
		$views = (int) get_post_meta( $id, '_mm_views', true );
		$ig    = get_post_meta( $id, '_mm_ig', true ) ?: MM_INSTAGRAM;
		$h    .= '<article class="mm-reel"><a href="' . esc_url( $ig ) . '" target="_blank" rel="noopener" class="mm-reel__media" aria-label="Watch the ' . esc_attr( $p->get_name() ) . ' walk-around on Instagram">' . $p->get_image( 'woocommerce_single', [ 'loading' => 'lazy', 'alt' => '' ] ) . '<span class="mm-reel__play" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22"><path fill="currentColor" d="M8 5v14l11-7z"/></svg></span>' . ( $views ? '<span class="mm-reel__views">' . esc_html( number_format( $views ) ) . ' views</span>' : '' ) . '</a><a class="mm-reel__name" href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '<span>' . wp_kses_post( $p->get_price_html() ) . '</span></a></article>';
	}
	return $h . '</div>';
} );

// Product search also looks in the specs, so "diesel", "sunroof" or "4WD" find cars whose title doesn't say it.
add_filter( 'posts_search', function ( $search, $q ) {
	global $wpdb;
	$s = trim( (string) $q->get( 's' ) );
	if ( $s === '' || ! in_array( 'product', (array) $q->get( 'post_type' ), true ) ) {
		return $search;
	}
	$clause = function ( $word ) use ( $wpdb ) {
		$like = '%' . $wpdb->esc_like( $word ) . '%';
		return $wpdb->prepare(
			"({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_content LIKE %s OR {$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('_mm_specs', '_mm_spec', '_sku') AND meta_value LIKE %s))",
			$like, $like, $like
		);
	};
	return ' AND ' . implode( ' AND ', array_map( $clause, array_filter( preg_split( '/\s+/', $s ) ) ) ) . ' ';
}, 10, 2 );

add_action( 'rest_api_init', function () {
	// Instant search in the header: the same search as the results page, as a short JSON list.
	register_rest_route( 'mm/v1', '/search', [
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$q = new WP_Query( [ 'post_type' => 'product', 'post_status' => 'publish', 's' => sanitize_text_field( $req['q'] ), 'posts_per_page' => 6, 'no_found_rows' => true ] );
			return array_map( function ( $post ) {
				$p = wc_get_product( $post );
				return [ 'name' => $p->get_name(), 'permalink' => $p->get_permalink(), 'image' => wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ), 'price_html' => $p->get_price_html(), 'badge' => get_post_meta( $p->get_id(), '_mm_spec', true ) ];
			}, $q->posts );
		},
	] );
	// Side-by-side comparison: up to three cars with their spec sheets.
	register_rest_route( 'mm/v1', '/compare', [
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$ids = array_slice( array_filter( array_map( 'absint', explode( ',', (string) $req['ids'] ) ) ), 0, 3 );
			$out = [];
			foreach ( $ids as $id ) {
				$p = wc_get_product( $id );
				if ( ! $p || $p->get_status() !== 'publish' ) {
					continue;
				}
				$out[] = [
					'id'        => $id,
					'name'      => $p->get_name(),
					'permalink' => $p->get_permalink(),
					'image'     => wp_get_attachment_image_url( $p->get_image_id(), 'woocommerce_single' ),
					'price'     => mm_ksh( $p->get_price() ),
					'monthly'   => $p->is_in_stock() ? mm_ksh( mm_from_monthly( (float) $p->get_price() ) ) : '',
					'stock'     => mm_stock_id( $p ),
					'available' => $p->is_in_stock(),
					'specs'     => mm_specs( $id ),
					'wa'        => mm_wa_link( mm_enquiry_text( $p ) ),
				];
			}
			return $out;
		},
	] );
} );

/* -------------------------------------------------------------------------
 * Filters and sorting
 * ---------------------------------------------------------------------- */

// The page being filtered, and the filter choices already in its address.
function mm_filter_state() {
	$current = get_queried_object();
	$base    = $current instanceof WP_Term ? get_term_link( $current ) : wc_get_page_permalink( 'shop' );
	$keep    = [];
	foreach ( array_merge( [ 'min_price', 'max_price', 'min_year', 'orderby', 's', 'post_type', 'product_cat' ], array_map( fn( $k ) => "filter_$k", array_keys( MM_FILTERS ) ) ) as $key ) {
		if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) { // phpcs:ignore -- read-only filter links.
			$keep[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) ); // phpcs:ignore
		}
	}
	return [ $current, is_wp_error( $base ) ? wc_get_page_permalink( 'shop' ) : $base, $keep ];
}

// One row of chips that each toggle a value in the address.
function mm_chip_row( $label, $param, $options, $keep, $link ) {
	$chosen = $keep[ $param ] ?? '';
	$h      = '<div class="mm-filters__row"><span class="mm-refine__label">' . esc_html( $label ) . '</span>';
	foreach ( $options as $value => $text ) {
		$on   = (string) $chosen === (string) $value;
		$args = $on ? array_diff_key( $keep, [ $param => 1 ] ) : array_merge( $keep, [ $param => $value ] );
		$h   .= sprintf( '<a class="mm-chip-link%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $text ) );
	}
	return $h . '</div>';
}

// Body type and make chips, then budget, year, fuel, gearbox and drive.
add_shortcode( 'mm_filters', function () {
	global $wpdb;
	[ $current, $base, $keep ] = mm_filter_state();
	$cur_id = $current instanceof WP_Term ? $current->term_id : 0;
	$link   = fn( $args ) => esc_url( add_query_arg( $args, $base ) );

	$h  = '<nav class="mm-filters" aria-label="Filter cars"><div class="mm-filters__row mm-filters__row--cats">';
	$h .= '<a class="mm-chip-link mm-chip-link--lg' . ( is_shop() && ! is_search() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All cars</a>';
	foreach ( mm_categories() as $t ) {
		$h .= sprintf( '<a class="mm-chip-link mm-chip-link--lg%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div><div class="mm-filters__row mm-filters__row--makes">';
	foreach ( mm_brands() as $t ) {
		$h .= sprintf( '<a class="mm-chip-link%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div>';

	// Cars on this page before any filter, to offer only the values that exist here.
	$args = [ 'post_type' => 'product', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => 500, 'no_found_rows' => true ];
	if ( $current instanceof WP_Term ) {
		$args['tax_query'] = [ [ 'taxonomy' => $current->taxonomy, 'terms' => [ $current->term_id ] ] ];
	}
	$ids = get_posts( $args );

	$chosen_budget = isset( $keep['min_price'] ) || isset( $keep['max_price'] ) ? (int) ( $keep['min_price'] ?? 0 ) . '-' . (int) ( $keep['max_price'] ?? 0 ) : '';
	$h .= '<div class="mm-filters__row"><span class="mm-refine__label">Budget</span>';
	foreach ( MM_BUDGETS as [ $label, $min, $max ] ) {
		$value = $min . '-' . $max;
		$on    = $chosen_budget === $value;
		$a     = array_diff_key( $keep, [ 'min_price' => 1, 'max_price' => 1 ] );
		if ( ! $on ) {
			$a = array_merge( $a, array_filter( [ 'min_price' => $min, 'max_price' => $max ] ) );
		}
		$h .= sprintf( '<a class="mm-chip-link%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $a ), esc_html( $label ) );
	}
	$h .= '</div>';

	$specs_on = array_intersect_key( $keep, array_flip( array_merge( [ 'min_price', 'max_price', 'min_year' ], array_map( fn( $k ) => "filter_$k", array_keys( MM_FILTERS ) ) ) ) );
	if ( count( $ids ) > 1 ) {
		$in  = implode( ',', array_map( 'intval', $ids ) );
		$top = (float) $wpdb->get_var( "SELECT MAX(max_price) FROM {$wpdb->wc_product_meta_lookup} WHERE product_id IN ($in)" ); // phpcs:ignore -- ids are integers.
		$top = (int) ( ceil( $top / 500000 ) * 500000 );
		$min = min( $top, max( 0, (int) ( $keep['min_price'] ?? 0 ) ) );
		$max = min( $top, (int) ( $keep['max_price'] ?? $top ) ) ?: $top;

		$h .= '<details class="mm-refine"' . ( $specs_on ? ' open' : '' ) . '><summary>Price slider, year, fuel, gearbox &amp; drive' . ( $specs_on ? ' <em>' . count( $specs_on ) . '</em>' : '' ) . '</summary><div class="mm-refine__body">';
		$h .= '<form class="mm-price" method="get" action="' . esc_url( $base ) . '" data-mm-price>';
		foreach ( array_diff_key( $keep, array_flip( [ 'min_price', 'max_price' ] ) ) as $k => $v ) {
			$h .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		$h .= sprintf(
			'<span class="mm-refine__label">Price</span><div class="mm-price__sliders"><input type="range" name="min_price" min="0" max="%1$d" step="50000" value="%2$d" aria-label="Lowest price"><input type="range" name="max_price" min="0" max="%1$d" step="50000" value="%3$d" aria-label="Highest price"></div><output>KSh %4$s – KSh %5$s</output><button class="mm-chip-link is-on" type="submit">Apply</button></form>',
			$top, $min, $max, number_format( $min ), number_format( $max )
		);
		$h .= mm_chip_row( 'Year', 'min_year', MM_YEARS, $keep, $link );
		foreach ( MM_FILTERS as $key => $label ) {
			$terms = wp_get_object_terms( $ids, wc_attribute_taxonomy_name( $key ) );
			if ( is_wp_error( $terms ) || count( $terms ) < 2 ) {
				continue;
			}
			$h .= mm_chip_row( $label, "filter_$key", wp_list_pluck( $terms, 'name', 'slug' ), $keep, $link );
		}
		$h .= '</div></details>';
	}
	if ( array_diff_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ) ) {
		$h .= '<a class="mm-refine__clear" href="' . esc_url( add_query_arg( array_intersect_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ), $base ) ) . '">✕ Clear filters</a>';
	}
	return $h . '</nav>';
} );

// Year limit from the address, on shop pages and on the product grid block.
function mm_meta_limits() {
	$year = (int) ( $_GET['min_year'] ?? 0 ); // phpcs:ignore -- read-only filter.
	return $year ? [ [ 'key' => '_mm_year', 'value' => $year, 'compare' => '>=', 'type' => 'NUMERIC' ] ] : [];
}
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( $limits = mm_meta_limits() ) {
		$q->set( 'meta_query', array_merge( (array) $q->get( 'meta_query' ), $limits ) );
	}
} );
add_filter( 'query_loop_block_query_vars', function ( $vars ) {
	if ( ( $vars['post_type'] ?? '' ) === 'product' && ( $limits = mm_meta_limits() ) && ( is_shop() || is_product_taxonomy() || is_search() ) ) {
		$vars['meta_query'] = array_merge( (array) ( $vars['meta_query'] ?? [] ), $limits );
	}
	return $vars;
} );

// Sort by model year as well as price.
add_filter( 'woocommerce_catalog_orderby', function ( $options ) {
	unset( $options['popularity'], $options['rating'] );
	$options['menu_order'] = 'Newest listings';
	return array_merge( $options, [ 'year' => 'Model year: newest first' ] );
} );
add_filter( 'woocommerce_get_catalog_ordering_args', function ( $args, $orderby ) {
	return $orderby === 'year' ? [ 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => '_mm_year' ] : $args;
}, 10, 2 );
add_filter( 'query_loop_block_query_vars', function ( $vars ) {
	if ( ( $vars['post_type'] ?? '' ) === 'product' && sanitize_key( $_GET['orderby'] ?? '' ) === 'year' ) { // phpcs:ignore -- read-only sort.
		$vars['meta_key'] = '_mm_year';
		$vars['orderby']  = 'meta_value_num';
		$vars['order']    = 'DESC';
	}
	return $vars;
}, 20 );

add_shortcode( 'mm_wishlist', fn() => '<div class="mm-wishlist" data-mm-wishlist><p class="mm-small">Loading your saved cars…</p></div>' );
add_shortcode( 'mm_compare', fn() => '<div class="mm-compare" data-mm-compare-page><p class="mm-small">Loading your comparison…</p></div>' );

/* -------------------------------------------------------------------------
 * Requests: trade-in valuations, car finder, test drives, finance pre-approval
 * ---------------------------------------------------------------------- */

// Every request is kept for staff (WooCommerce → Requests) and gets a reference number.
add_action( 'init', function () {
	register_post_type( 'mm_request', [
		'label'           => 'Requests',
		'labels'          => [ 'name' => 'Requests', 'singular_name' => 'Request', 'edit_item' => 'Request', 'all_items' => 'Requests' ],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'woocommerce',
		'supports'        => [ 'title', 'editor' ],
		'capability_type' => 'post',
		'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap'    => true,
	] );
} );

// type => [title, reference letter, WhatsApp opening line].
const MM_REQUEST_TYPES = [
	'tradein'   => [ 'Trade-in valuation', 'V', "Hi Moti Moto-Rs, please value my car for a trade-in" ],
	'find'      => [ 'Car finder', 'C', "Hi Moti Moto-Rs, please find me a car" ],
	'testdrive' => [ 'Test drive', 'D', "Hi Moti Moto-Rs, I'd like to test drive a car" ],
	'finance'   => [ 'Finance pre-approval', 'F', "Hi Moti Moto-Rs, I'd like to get pre-approved for financing" ],
];
// What each form sends: field => label. Required fields end in "*".
const MM_REQUEST_FIELDS = [
	'tradein'   => [ 'make*' => 'Make', 'model*' => 'Model', 'year*' => 'Year', 'mileage*' => 'Mileage', 'condition' => 'Condition', 'reg' => 'Registration', 'want' => 'Trading in for', 'name*' => 'Name', 'phone*' => 'Phone', 'notes' => 'Notes' ],
	'find'      => [ 'make*' => 'Make', 'model*' => 'Model', 'years' => 'Years', 'budget*' => 'Budget', 'source' => 'Local or import', 'fuel' => 'Fuel', 'transmission' => 'Gearbox', 'pay' => 'Paying by', 'name*' => 'Name', 'phone*' => 'Phone', 'notes' => 'Notes' ],
	'testdrive' => [ 'car*' => 'Car', 'url' => 'Link', 'date*' => 'Date', 'time*' => 'Time', 'name*' => 'Name', 'phone*' => 'Phone' ],
	'finance'   => [ 'car' => 'Car', 'price' => 'Price', 'deposit' => 'Deposit', 'term' => 'Term', 'monthly' => 'Estimate', 'employment*' => 'Income from', 'name*' => 'Name', 'phone*' => 'Phone' ],
];

add_filter( 'manage_mm_request_posts_columns', fn( $c ) => [ 'cb' => $c['cb'], 'title' => 'Request', 'mm_type' => 'Type', 'mm_phone' => 'Phone', 'date' => 'Received' ] );
add_action( 'manage_mm_request_posts_custom_column', function ( $col, $id ) {
	if ( $col === 'mm_type' ) {
		echo esc_html( MM_REQUEST_TYPES[ get_post_meta( $id, '_mm_type', true ) ][0] ?? '' );
	}
	if ( $col === 'mm_phone' ) {
		$phone = get_post_meta( $id, '_mm_phone', true );
		echo '<a href="' . esc_url( mm_wa_link_to( $phone ) ) . '" target="_blank" rel="noopener">' . esc_html( $phone ) . '</a>';
	}
}, 10, 2 );
// WhatsApp link to a customer's number (07… or +254…).
function mm_wa_link_to( $phone ) {
	$digits = preg_replace( '/\D/', '', (string) $phone );
	if ( str_starts_with( $digits, '0' ) ) {
		$digits = '254' . substr( $digits, 1 );
	}
	return 'https://wa.me/' . $digits;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mm/v1', '/request', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$type = sanitize_key( $req['type'] );
			if ( ! isset( MM_REQUEST_FIELDS[ $type ] ) ) {
				return new WP_Error( 'mm_type', 'Unknown request.', [ 'status' => 400 ] );
			}
			// A field people can't see: only bots fill it in.
			if ( ! empty( $req['website'] ) ) {
				return new WP_Error( 'mm_spam', 'Request not sent.', [ 'status' => 400 ] );
			}
			// A few requests per visitor per ten minutes.
			$ip   = 'mm_rl_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' );
			$hits = (int) get_transient( $ip );
			if ( $hits >= 8 ) {
				return new WP_Error( 'mm_slow', 'Too many requests. Please call or WhatsApp us on ' . MM_PHONE . '.', [ 'status' => 429 ] );
			}
			set_transient( $ip, $hits + 1, 10 * MINUTE_IN_SECONDS );

			$data = [];
			foreach ( MM_REQUEST_FIELDS[ $type ] as $key => $label ) {
				$field = rtrim( $key, '*' );
				$value = trim( sanitize_text_field( (string) $req[ $field ] ) );
				if ( $field === 'url' ) {
					$value = esc_url_raw( (string) $req[ $field ] );
				}
				if ( $field === 'date' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
					$value = wp_date( 'D j M Y', strtotime( $value . ' 12:00' ) );
				}
				if ( $value === '' && str_ends_with( $key, '*' ) ) {
					return new WP_Error( 'mm_missing', 'Please fill in: ' . $label . '.', [ 'status' => 400 ] );
				}
				$data[ $field ] = mb_substr( $value, 0, 600 );
			}
			$rows = [];
			foreach ( MM_REQUEST_FIELDS[ $type ] as $key => $label ) {
				$field = rtrim( $key, '*' );
				if ( $data[ $field ] !== '' ) {
					$rows[] = $label . ': ' . $data[ $field ];
				}
			}
			[ $title, $letter, $intro ] = MM_REQUEST_TYPES[ $type ];
			$id = wp_insert_post( [ 'post_type' => 'mm_request', 'post_status' => 'publish', 'post_title' => $title . ' – ' . $data['name'], 'post_content' => implode( "\n", $rows ) ] );
			if ( ! $id || is_wp_error( $id ) ) {
				return new WP_Error( 'mm_save', 'Could not save your request. Please WhatsApp us on ' . MM_PHONE . '.', [ 'status' => 500 ] );
			}
			$ref = 'MM-' . $letter . $id;
			update_post_meta( $id, '_mm_type', $type );
			update_post_meta( $id, '_mm_phone', $data['phone'] );
			update_post_meta( $id, '_mm_ref', $ref );
			wp_update_post( [ 'ID' => $id, 'post_title' => $title . ' – ' . $data['name'] . ' (' . $ref . ')' ] );
			wp_mail( get_option( 'admin_email' ), 'New request ' . $ref, $title . "\n\n" . implode( "\n", $rows ) );

			$text = $intro . " (ref $ref):\n" . implode( "\n", array_filter( $rows, fn( $r ) => ! str_starts_with( $r, 'Phone:' ) ) );
			return [ 'ref' => $ref, 'wa' => mm_wa_link( $text ) ];
		},
	] );
} );

// The thank-you panel every request form swaps in.
function mm_done_panel( $heading, $line ) {
	return '<div class="mm-done" data-mm-done hidden><span class="mm-done__tick" aria-hidden="true">✓</span><h3>' . esc_html( $heading ) . '</h3><p>Your reference is <strong data-mm-ref></strong>. ' . esc_html( $line ) . '</p><a class="wp-element-button mm-wa-btn" data-mm-done-wa href="#" target="_blank" rel="noopener">' . MM_WA_ICON . 'Send it on WhatsApp</a><p class="mm-small">Prefer to call? <a href="tel:' . MM_TEL . '">' . MM_PHONE . '</a></p></div>';
}
function mm_make_options( $selected = '' ) {
	$h = '';
	foreach ( MM_MAKES as $m ) {
		$h .= '<option' . ( $selected && stripos( $selected, $m ) === 0 ? ' selected' : '' ) . '>' . esc_html( $m ) . '</option>';
	}
	return $h;
}

// Trade-in valuation form: on the Sell / trade-in page and in the pop-up on each car.
function mm_tradein_form( $in_dialog = false ) {
	$want = sanitize_text_field( wp_unslash( $_GET['for'] ?? '' ) ); // phpcs:ignore -- prefill only.
	$cond = '';
	foreach ( [ 'Excellent: no faults', 'Good: small marks', 'Fair: needs some work', 'Needs repairs' ] as $i => $c ) {
		$cond .= '<label class="mm-pill"><input type="radio" name="condition" value="' . esc_attr( $c ) . '"' . ( $i === 1 ? ' checked' : '' ) . '><span>' . esc_html( strtok( $c, ':' ) ) . '</span></label>';
	}
	ob_start();
	?>
	<form class="mm-form mm-tradein" data-mm-request="tradein" <?php echo $in_dialog ? '' : 'id="value"'; ?> novalidate>
		<?php if ( $in_dialog ) : ?>
			<p class="mm-eyebrow">Trade-in estimator</p><h2 id="mm-ti-h">Trade in for the <span data-mm-ti-car></span></h2>
			<p class="mm-small">Tell us about your current car. We value it against this one and send you the top-up figure on WhatsApp.</p>
			<input type="hidden" name="want">
		<?php else : ?>
			<h2>Get your car valued</h2>
			<p class="mm-small">Selling outright or trading up? Tell us about it and we'll come back with a valuation on WhatsApp.</p>
		<?php endif; ?>
		<div class="mm-grid2">
			<label>Make<select name="make" required><option value="">Choose…</option><?php echo mm_make_options(); // phpcs:ignore -- escaped. ?></select></label>
			<label>Model<input name="model" required placeholder="e.g. Fielder, Demio, X-Trail"></label>
			<label>Year<input name="year" required inputmode="numeric" maxlength="4" placeholder="e.g. 2012"></label>
			<label>Mileage<input name="mileage" required inputmode="numeric" placeholder="e.g. 120,000 km"></label>
			<fieldset class="mm-span2"><legend>Condition</legend><div class="mm-pills"><?php echo $cond; // phpcs:ignore ?></div></fieldset>
			<label>Registration (optional)<input name="reg" placeholder="e.g. KCX 123A" autocapitalize="characters"></label>
			<?php if ( ! $in_dialog ) : ?>
				<label>Car you'd like instead (optional)<input name="want" value="<?php echo esc_attr( $want ); ?>" placeholder="e.g. 2015 Subaru Forester"></label>
			<?php endif; ?>
			<label>Your name<input name="name" required autocomplete="name"></label>
			<label>Phone / WhatsApp<input name="phone" type="tel" required autocomplete="tel" placeholder="07…"></label>
			<label class="mm-span2">Anything else? (optional)<textarea name="notes" rows="2" placeholder="Service history, accident repairs, logbook with a bank…"></textarea></label>
		</div>
		<input class="mm-hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
		<p class="mm-error" data-mm-error role="alert" hidden></p>
		<button class="wp-element-button" type="submit">Value my car</button>
		<?php echo mm_done_panel( 'Valuation requested', 'We\'ll send your valuation on WhatsApp. Tap below to send the details (and a few photos) now.' ); // phpcs:ignore ?>
	</form>
	<?php
	// No line breaks between tags: the shortcode block runs wpautop, which would add <br> into the form grid.
	return preg_replace( '/>\s+</', '><', ob_get_clean() );
}
add_shortcode( 'mm_tradein', fn() => mm_tradein_form() );

// Car finder: "can't see it? we'll find it", locally or imported.
add_shortcode( 'mm_find', function () {
	$like    = sanitize_text_field( wp_unslash( $_GET['like'] ?? '' ) ); // phpcs:ignore -- prefill only.
	$model   = $like ? trim( preg_replace( '/^(' . implode( '|', array_map( 'preg_quote', MM_MAKES ) ) . ')\s+/i', '', $like ) ) : '';
	$sources = '';
	foreach ( [ 'Locally used is fine', 'Fresh import (Japan, UK, Australia)', 'Either' ] as $i => $o ) {
		$sources .= '<label class="mm-pill"><input type="radio" name="source" value="' . esc_attr( $o ) . '"' . ( $i === 2 ? ' checked' : '' ) . '><span>' . esc_html( $o ) . '</span></label>';
	}
	$budgets = '';
	foreach ( [ 'Up to KSh 700K', 'KSh 700K – 1M', 'KSh 1M – 1.5M', 'KSh 1.5M – 2.5M', 'KSh 2.5M – 4M', 'KSh 4M +' ] as $b ) {
		$budgets .= '<option>' . esc_html( $b ) . '</option>';
	}
	ob_start();
	?>
	<form class="mm-form mm-find" data-mm-request="find" id="request" novalidate>
		<h2>Tell us the car you want</h2>
		<p class="mm-small">We search clean, verified units around Nairobi or import one to your spec, and send you real options with photos and prices.</p>
		<fieldset><legend>Where from</legend><div class="mm-pills"><?php echo $sources; // phpcs:ignore ?></div></fieldset>
		<div class="mm-grid2">
			<label>Make<select name="make" required><option value="">Choose…</option><?php echo mm_make_options( $like ); // phpcs:ignore ?></select></label>
			<label>Model<input name="model" required value="<?php echo esc_attr( $model ); ?>" placeholder="e.g. Harrier, CX-5, C 200"></label>
			<label>Years<select name="years"><option>Any year</option><option>2018 or newer</option><option>2015 – 2017</option><option>2010 – 2014</option><option>Older is fine</option></select></label>
			<label>Budget<select name="budget" required><option value="">Choose…</option><?php echo $budgets; // phpcs:ignore ?></select></label>
			<label>Fuel<select name="fuel"><option>Either</option><option>Petrol</option><option>Diesel</option><option>Hybrid</option></select></label>
			<label>Gearbox<select name="transmission"><option>Automatic</option><option>Manual</option><option>Either</option></select></label>
			<label class="mm-span2">Paying by<select name="pay"><option>Cash</option><option>Financing</option><option>Trade-in plus top-up</option></select></label>
			<label>Your name<input name="name" required autocomplete="name"></label>
			<label>Phone / WhatsApp<input name="phone" type="tel" required autocomplete="tel" placeholder="07…"></label>
			<label class="mm-span2">Must-haves (optional)<textarea name="notes" rows="3" placeholder="Sunroof, 7 seats, diesel, colour…"></textarea></label>
		</div>
		<input class="mm-hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
		<p class="mm-error" data-mm-error role="alert" hidden></p>
		<button class="wp-element-button" type="submit">Find my car</button>
		<?php echo mm_done_panel( 'Request received', 'We\'ll come back with options on WhatsApp. Tap below to send it to us now.' ); // phpcs:ignore ?>
	</form>
	<?php
	return preg_replace( '/>\s+</', '><', ob_get_clean() );
} );

/* -------------------------------------------------------------------------
 * Pop-ups, compare bar, cart, checkout, reservation
 * ---------------------------------------------------------------------- */

add_action( 'wp_footer', function () {
	$slots = '';
	foreach ( MM_SLOTS as $s ) {
		$slots .= '<option>' . esc_html( $s ) . '</option>';
	}
	echo '<dialog id="mm-qv" class="mm-dialog mm-qv" aria-label="Quick view"><form method="dialog"><button class="mm-dialog__close" aria-label="Close">×</button></form><div data-mm-qv-body></div></dialog>';
	echo '<dialog id="mm-td" class="mm-dialog mm-dialog--sm" aria-labelledby="mm-td-h"><form method="dialog"><button class="mm-dialog__close" aria-label="Close">×</button></form>'
		. '<form class="mm-form" data-mm-request="testdrive" novalidate><p class="mm-eyebrow">Book a test drive</p><h2 id="mm-td-h" data-mm-td-car></h2>'
		. '<input type="hidden" name="car"><input type="hidden" name="url">'
		. '<div class="mm-grid2"><label>Date<input type="date" name="date" required data-mm-date></label><label>Time<select name="time" required>' . $slots . '</select></label>'
		. '<label>Your name<input name="name" required autocomplete="name"></label><label>Phone<input name="phone" type="tel" required autocomplete="tel" placeholder="07…"></label></div>'
		. '<p class="mm-small" data-mm-date-note>Monday to Saturday. Bring your driving licence.</p>'
		. '<input class="mm-hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true"><p class="mm-error" data-mm-error role="alert" hidden></p>'
		. '<button class="wp-element-button" type="submit">Book test drive</button>'
		. mm_done_panel( 'Test drive booked', 'We\'ll call to confirm the time and send you the location pin.' )
		. '</form></dialog>';
	if ( is_product() ) {
		echo '<dialog id="mm-ti" class="mm-dialog" aria-labelledby="mm-ti-h"><form method="dialog"><button class="mm-dialog__close" aria-label="Close">×</button></form>' . mm_tradein_form( true ) . '</dialog>'; // phpcs:ignore
	}
	echo '<dialog id="mm-fa" class="mm-dialog mm-dialog--sm" aria-labelledby="mm-fa-h"><form method="dialog"><button class="mm-dialog__close" aria-label="Close">×</button></form>'
		. '<form class="mm-form" data-mm-request="finance" novalidate><p class="mm-eyebrow">Financing</p><h2 id="mm-fa-h">Get pre-approved</h2>'
		. '<div class="mm-fa-sum" data-mm-fa-sum></div>'
		. '<input type="hidden" name="car"><input type="hidden" name="price"><input type="hidden" name="deposit"><input type="hidden" name="term"><input type="hidden" name="monthly">'
		. '<fieldset><legend>Your income is from</legend><div class="mm-pills"><label class="mm-pill"><input type="radio" name="employment" value="Employment (payslips)" required><span>Employment</span></label><label class="mm-pill"><input type="radio" name="employment" value="Own business"><span>Own business</span></label><label class="mm-pill"><input type="radio" name="employment" value="Other"><span>Other</span></label></div></fieldset>'
		. '<div class="mm-grid2"><label>Your name<input name="name" required autocomplete="name"></label><label>Phone<input name="phone" type="tel" required autocomplete="tel" placeholder="07…"></label></div>'
		. '<p class="mm-small">Usually needed: ID or passport, KRA PIN, 6 months\' bank statements and payslips (or business records). We\'ll confirm the list for your financier.</p>'
		. '<input class="mm-hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true"><p class="mm-error" data-mm-error role="alert" hidden></p>'
		. '<button class="wp-element-button" type="submit">Send for pre-approval</button>'
		. mm_done_panel( 'Request received', 'We\'ll call you about the documents and the financier\'s terms.' )
		. '</form></dialog>';
	echo '<div class="mm-cmpbar" data-mm-cmpbar hidden><div class="mm-cmpbar__cars" data-mm-cmpbar-cars></div><a class="wp-element-button" href="' . esc_url( home_url( '/compare/' ) ) . '">Compare <span data-mm-cmpbar-n></span></a><button type="button" class="mm-cmpbar__clear" data-mm-cmp-clear>Clear</button></div>';
} );

function mm_wa_cart_html() {
	return '<button type="button" class="mm-wa-cart" data-mm-wa-cart>' . MM_WA_ICON . 'Send this to WhatsApp instead</button>';
}
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . mm_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="mm-wa-cart-wrap">' . mm_wa_cart_html() . '</div>' );
add_filter( 'render_block_woocommerce/cart', fn( $c ) => '<p class="mm-reserve-note"><strong>Nothing is paid online.</strong> Reserving holds the car while you arrange a viewing and test drive. Clean units move fast, so this keeps it off the market for you.</p>' . $c );

// Checkout words fit a reservation, not a parcel.
add_filter( 'render_block_data', function ( $block ) {
	if ( $block['blockName'] === 'woocommerce/checkout-actions-block' ) {
		$block['attrs']['placeOrderButtonLabel'] = 'Reserve & book my viewing';
	}
	if ( $block['blockName'] === 'woocommerce/proceed-to-checkout-block' ) {
		$block['attrs']['buttonLabel'] = 'Reserve & book a viewing';
	}
	// "More verified cars" under a car: one full row of four.
	if ( $block['blockName'] === 'woocommerce/product-collection' && ( $block['attrs']['collection'] ?? '' ) === 'woocommerce/product-collection/related' ) {
		$block['attrs']['query']['perPage']         = 4;
		$block['attrs']['displayLayout']['columns'] = 4;
	}
	return $block;
} );

// How the buyer wants to see the car and pay for it: field => [label, short label, options].
const MM_CHECKOUT_FIELDS = [
	'mm/viewing' => [ 'Viewing preference', 'Viewing', [ 'lavington' => 'Viewing and test drive in person', 'video' => 'A live video walk-around first', 'mechanic' => 'Viewing with my own mechanic' ] ],
	'mm/payment' => [ 'How you\'ll pay', 'Paying by', [ 'cash' => 'Cash (bank transfer)', 'finance' => 'Financing: help me apply', 'tradein' => 'Trade-in plus top-up' ] ],
];
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	foreach ( MM_CHECKOUT_FIELDS as $id => [ $label, , $options ] ) {
		woocommerce_register_additional_checkout_field( [
			'id'       => $id,
			'label'    => $label,
			'location' => 'order',
			'type'     => 'select',
			'required' => true,
			'options'  => array_map( fn( $v, $l ) => [ 'value' => $v, 'label' => $l ], array_keys( $options ), $options ),
		] );
	}
} );

function mm_reservation_code( WC_Order $order ) {
	return 'MM-R' . $order->get_order_number();
}
function mm_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Moti Moto-Rs, I just reserved online (' . mm_reservation_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$product = $item->get_product();
		$lines[] = '• ' . $item->get_name() . ( $product ? ', stock ID ' . mm_stock_id( $product ) : '' ) . ' – ' . mm_ksh( $item->get_total() );
	}
	foreach ( MM_CHECKOUT_FIELDS as $key => [ , $label, $options ] ) {
		$value = (string) $order->get_meta( '_wc_other/' . $key );
		if ( $value !== '' ) {
			$lines[] = $label . ': ' . ( $options[ $value ] ?? $value );
		}
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return mm_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	return $content . '<div class="mm-thanks"><p class="mm-thanks__code">Reservation number <strong>' . esc_html( mm_reservation_code( $order ) ) . '</strong></p><ol><li>We call you shortly to confirm the car is held for you.</li><li>We agree a time for your viewing and test drive.</li><li>You pay (cash, financing or trade-in plus top-up) only once you\'re happy with the car.</li></ol><a class="wp-element-button mm-wa-btn" href="' . esc_attr( mm_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . MM_WA_ICON . 'Send my reservation to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Reservation number:</strong> ' . esc_html( mm_reservation_code( $order ) ) . '</p>';
} );

/* -------------------------------------------------------------------------
 * New-arrival alerts
 * ---------------------------------------------------------------------- */

add_action( 'admin_post_nopriv_mm_subscribe', 'mm_subscribe' );
add_action( 'admin_post_mm_subscribe', 'mm_subscribe' );
function mm_subscribe() {
	check_admin_referer( 'mm_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'mm_sub', 'invalid', $back ) . '#alerts' );
		exit;
	}
	$list = get_option( 'mm_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'mm_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'mm_sub', 'ok', $back ) . '#alerts' );
	exit;
}
add_shortcode( 'mm_newsletter', function () {
	$state = sanitize_key( $_GET['mm_sub'] ?? '' ); // phpcs:ignore
	if ( $state === 'ok' ) {
		return '<p class="mm-news-ok"><strong>You\'re on the list.</strong> New arrivals land in your inbox before they hit the general market.</p>';
	}
	$err = $state === 'invalid' ? '<p class="mm-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="mm-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="mm_subscribe">'
		. wp_nonce_field( 'mm_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Get alerts</button>'
		. '</form>' . $err;
} );
add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Arrival alerts', 'Arrival alerts', 'manage_woocommerce', 'mm-subscribers', function () {
		$list = get_option( 'mm_subscribers', [] );
		echo '<div class="wrap"><h1>New-arrival alerts (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Joined</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

/* -------------------------------------------------------------------------
 * Car details on the product screen
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group">';
	woocommerce_wp_text_input( [ 'id' => '_mm_year', 'label' => 'Year of manufacture', 'type' => 'number', 'description' => 'Used by the year filter and sorting.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_mm_spec', 'label' => 'Card line', 'description' => 'Short line on the car card, e.g. "2,000cc · Petrol · Auto".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_mm_specs', 'label' => 'Spec sheet', 'rows' => 10, 'description' => 'One per line, as "Label: value", e.g. "Engine: 2,000cc".' ] );
	woocommerce_wp_checkbox( [ 'id' => '_mm_ready', 'label' => 'Ready transfer', 'description' => 'All documents available: shows the "Ready transfer" chip.' ] );
	woocommerce_wp_checkbox( [ 'id' => '_mm_arrived', 'label' => 'Just in', 'description' => 'Shows the "Just in" ribbon.' ] );
	woocommerce_wp_text_input( [ 'id' => '_mm_ig', 'label' => 'Instagram reel', 'type' => 'url' ] );
	woocommerce_wp_text_input( [ 'id' => '_mm_views', 'label' => 'Reel views', 'type' => 'number', 'description' => 'Shown on the home page\'s most-watched walk-arounds.', 'desc_tip' => true ] );
	echo '</div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_mm_spec' => 'sanitize_text_field', '_mm_specs' => 'sanitize_textarea_field', '_mm_ig' => 'esc_url_raw', '_mm_year' => 'absint', '_mm_views' => 'absint' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) { // phpcs:ignore -- WooCommerce checks the product nonce.
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) ); // phpcs:ignore
		}
	}
	$product->update_meta_data( '_mm_ready', isset( $_POST['_mm_ready'] ) ? 'yes' : 'no' ); // phpcs:ignore
	$product->update_meta_data( '_mm_arrived', isset( $_POST['_mm_arrived'] ) ? 'yes' : 'no' ); // phpcs:ignore
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan details: no postcode or street address needed to reserve a car.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_2'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']      = [ 'label' => 'Area / town (e.g. Kilimani, Kileleshwa, Nakuru)' ];
	$locale['KE']['state']     = [ 'label' => 'County' ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );
add_filter( 'woocommerce_get_country_locale_default', function ( $locale ) {
	$locale['company'] = [ 'hidden' => true, 'required' => false ];
	return $locale;
} );

// Demo stores ship web-sized photos and skip thumbnails (see setup.php).
if ( get_option( 'mm_fast_images' ) === 'yes' ) {
	add_filter( 'woocommerce_resize_images', '__return_false' );
	add_filter( 'woocommerce_background_image_regeneration', '__return_false' );
}

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#121212\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src|action)="/(?!/)#', '$1="' . $home, $content );
} );

// The site shows no WordPress toolbar, version tags or discovery links. Staff work from /wp-admin.
add_filter( 'show_admin_bar', '__return_false' );
add_filter( 'the_generator', '__return_empty_string' );
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'emoji_svg_url', '__return_false' );
add_filter( 'wp_headers', function ( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
} );
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'feed_links', 2 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_footer_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
} );

// The staff login page carries the dealership's mark instead of the WordPress one.
add_action( 'login_enqueue_scripts', function () {
	$logo = esc_url( get_stylesheet_directory_uri() . '/assets/logo.png' );
	echo "<style>body.login{background:#121212}body.login #login h1 a{background:url($logo) center/contain no-repeat;width:260px;height:97px}body.login #nav a{color:#FAFAFA}#backtoblog,.language-switcher{display:none}.wp-core-ui .button-primary{background:#D32F2F;border-color:#D32F2F}</style>";
} );
add_filter( 'login_title', fn( $title ) => str_replace( [ ' &#8212; WordPress', ' — WordPress' ], '', $title ) );
add_filter( 'login_headerurl', fn() => home_url( '/' ) );
add_filter( 'login_headertext', fn() => 'MOTi Moto-Rs' );

// Car words for WooCommerce's shop words.
add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) {
		return $text;
	}
	return [
		'Related products'          => 'More verified cars',
		'You may also like&hellip;' => 'More verified cars',
		'Continue shopping'         => 'Keep browsing',
		'Order received'            => 'Car reserved',
		'Thank you. Your order has been received.' => 'Thank you. The car is reserved for you.',
		'SKU:'                      => 'Stock ID:',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', function ( $text, $single, $plural, $number, $domain ) {
	return $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s is reserved for you. Nothing to pay yet.' : $text;
}, 10, 5 );
