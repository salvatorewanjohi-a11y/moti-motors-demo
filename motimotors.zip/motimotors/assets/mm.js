( function () {
	const cfg = window.MM || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-KE' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
	const waIcon = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Z"/></svg>';
	const waLink = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const enquiry = ( name, price, stock, url ) => 'Hi Moti Moto-Rs, I\'m interested in the ' + name + ( price ? ' (' + price + ')' : '' ) + ( stock ? ', stock ID ' + stock : '' ) + '. Is it still available? ' + url;
	const store = {
		read( key ) {
			try {
				return JSON.parse( localStorage.getItem( key ) || '[]' ).map( Number ).filter( Boolean );
			} catch ( e ) {
				return [];
			}
		},
		write( key, ids ) {
			try {
				localStorage.setItem( key, JSON.stringify( ids ) );
			} catch ( e ) {}
		},
	};

	/* Monthly repayment on a reducing balance -------------------------- */
	const monthly = ( loan, months, rate ) => {
		const r = rate / 100 / 12;
		return r ? ( loan * r ) / ( 1 - Math.pow( 1 + r, -months ) ) : loan / months;
	};

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.mm-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'mm-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'mm-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3400 );
		setTimeout( () => t.remove(), 3900 );
	}
	// "Reserve this car" goes to the reservation page; the notice there says so, the toast makes it pop.
	if ( document.querySelector( '.woocommerce-message, .wc-block-components-notice-banner.is-success' ) && /reserved for you/i.test( document.body.textContent ) ) {
		setTimeout( () => toast( '✓ Car reserved for you. Nothing to pay yet.' ), 300 );
	}

	/* WhatsApp instead of checkout --------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-mm-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await ( await fetch( cfg.store + 'cart', { credentials: 'same-origin' } ) ).json();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Nothing reserved yet.' );
				return;
			}
			const lines = [ 'Hi Moti Moto-Rs, I\'d like to reserve:' ];
			cart.items.forEach( ( it ) => {
				lines.push( '• ' + plain( it.name ) + ( it.sku ? ', stock ID ' + it.sku : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) + '\n  ' + it.permalink );
			} );
			lines.push( 'When can I come for a viewing?' );
			const url = waLink( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your reservation. Please try again.' );
		}
	} );

	/* Saved cars and compare list --------------------------------------- */
	const WISH = 'mm-saved';
	const CMP = 'mm-compare';
	const CMP_MAX = 3;
	function paintLists() {
		const wish = store.read( WISH );
		const cmp = store.read( CMP );
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		const sync = ( sel, attr, ids ) => $$( sel ).forEach( ( b ) => {
			const on = ids.includes( Number( b.getAttribute( attr ) ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		sync( '[data-mm-wish]', 'data-mm-wish', wish );
		sync( '[data-mm-compare]:not(.mm-cmp-x)', 'data-mm-compare', cmp );
		const count = ( sel, n ) => $$( sel ).forEach( ( el ) => {
			if ( el.textContent !== String( n ) ) el.textContent = n;
			el.hidden = n === 0;
		} );
		count( '[data-mm-wish-count]', wish.length );
		count( '[data-mm-cmp-count]', cmp.length );
		const bar = document.querySelector( '[data-mm-cmpbar]' );
		if ( bar ) {
			const show = cmp.length > 0 && ! document.querySelector( '[data-mm-compare-page]' );
			if ( bar.hidden === show ) {
				bar.hidden = ! show;
				document.body.classList.toggle( 'has-cmpbar', show );
			}
			const n = bar.querySelector( '[data-mm-cmpbar-n]' );
			const label = '(' + cmp.length + ')';
			if ( n.textContent !== label ) {
				n.textContent = label;
				paintBarThumbs( cmp );
			}
		}
	}
	async function paintBarThumbs( ids ) {
		const box = document.querySelector( '[data-mm-cmpbar-cars]' );
		if ( ! box || ! ids.length ) return;
		try {
			const items = await ( await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=3' ) ).json();
			box.innerHTML = items.map( ( p ) => ( p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="' + esc( plain( p.name ) ) + '">' : '' ) ).join( '' );
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-mm-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.mmWish );
		let ids = store.read( WISH );
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		store.write( WISH, ids );
		paintLists();
		toast( on ? 'Removed from your saved cars' : '♥ Saved. See your <a href="' + esc( cfg.home || '/' ) + 'saved-cars/">saved cars</a>' );
		if ( b.closest( '[data-mm-wishlist]' ) ) renderWishlist();
	} );
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-mm-compare]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.mmCompare );
		let ids = store.read( CMP );
		if ( ids.includes( id ) ) {
			ids = ids.filter( ( x ) => x !== id );
			toast( 'Removed from compare' );
		} else if ( ids.length >= CMP_MAX ) {
			toast( 'You can compare up to ' + CMP_MAX + ' cars. <a href="' + esc( cfg.compare ) + '">Open the comparison</a>' );
			return;
		} else {
			ids = [ ...ids, id ];
			toast( '⚖ Added to compare (' + ids.length + '/' + CMP_MAX + '). <a href="' + esc( cfg.compare ) + '">Compare now</a>' );
		}
		store.write( CMP, ids );
		paintLists();
		if ( b.closest( '[data-mm-compare-page]' ) ) renderCompare();
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( ! e.target.closest( '[data-mm-cmp-clear]' ) ) return;
		store.write( CMP, [] );
		paintLists();
		toast( 'Comparison cleared' );
	} );

	async function renderWishlist() {
		const box = document.querySelector( '[data-mm-wishlist]' );
		if ( ! box ) return;
		const ids = store.read( WISH );
		if ( ! ids.length ) {
			box.innerHTML = '<div class="mm-empty"><p>No saved cars yet. Tap the ♥ on any car to keep it here and compare later.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse verified cars</a></div>';
			return;
		}
		try {
			const items = await ( await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' ) ).json();
			box.innerHTML = '<div class="mm-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				const price = plain( p.price_html ).trim();
				return '<article class="mm-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<div class="mm-card-tools"><button type="button" class="mm-heart is-on" data-mm-wish="' + p.id + '" aria-label="Remove from saved cars" aria-pressed="true">' + heart + '</button></div>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="mm-wish-price">' + p.price_html + '</div>' +
					'<div class="mm-card-actions"><a class="mm-card-view" href="' + esc( p.permalink ) + '">' + ( p.is_in_stock ? 'View car' : 'Reserved · details' ) + '</a><a class="mm-card-wa" href="' + esc( waLink( enquiry( plain( p.name ), price, p.sku, p.permalink ) ) ) + '" target="_blank" rel="noopener" aria-label="Ask on WhatsApp">' + waIcon + '</a></div></article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your saved cars. Please refresh the page.</p>';
		}
	}

	// Compare page: up to three cars side by side, rows that differ highlighted.
	async function renderCompare() {
		const box = document.querySelector( '[data-mm-compare-page]' );
		if ( ! box ) return;
		const ids = store.read( CMP );
		if ( ! ids.length ) {
			box.innerHTML = '<div class="mm-empty"><p>Nothing to compare yet. Tap the ⚖ on up to three cars and they line up here, spec by spec.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse verified cars</a></div>';
			return;
		}
		try {
			const cars = await ( await fetch( cfg.api + 'compare&ids=' + ids.join( ',' ) ) ).json();
			const labels = [];
			cars.forEach( ( c ) => Object.keys( c.specs ).forEach( ( k ) => labels.includes( k ) || labels.push( k ) ) );
			const rows = [ [ 'Price', cars.map( ( c ) => c.price ) ], [ 'Monthly, from', cars.map( ( c ) => ( c.monthly ? c.monthly + ' /mo' : '—' ) ) ], [ 'Stock ID', cars.map( ( c ) => c.stock ) ] ]
				.concat( labels.map( ( k ) => [ k, cars.map( ( c ) => c.specs[ k ] || '—' ) ] ) );
			box.innerHTML = '<div class="mm-cmp-scroll"><table class="mm-cmp-table"><thead><tr><th></th>' + cars.map( ( c ) =>
				'<th><div class="mm-cmp-car"><button type="button" class="mm-cmp-x" data-mm-compare="' + c.id + '">✕ Remove</button><a href="' + esc( c.permalink ) + '"><img src="' + esc( c.image || '' ) + '" alt=""></a><a class="mm-cmp-name" href="' + esc( c.permalink ) + '">' + esc( c.name ) + '</a><span class="mm-cmp-price">' + esc( c.price ) + '</span>' +
				'<div class="mm-card-actions"><a class="mm-card-view" href="' + esc( c.permalink ) + '">' + ( c.available ? 'View car' : 'Reserved' ) + '</a><a class="mm-card-wa" href="' + esc( c.wa ) + '" target="_blank" rel="noopener" aria-label="Ask about the ' + esc( c.name ) + ' on WhatsApp">' + waIcon + '</a></div></div></th>'
			).join( '' ) + '</tr></thead><tbody>' + rows.map( ( [ k, vals ] ) =>
				'<tr' + ( cars.length > 1 && new Set( vals ).size > 1 ? ' class="is-diff"' : '' ) + '><th scope="row">' + esc( k ) + '</th>' + vals.map( ( v ) => '<td>' + esc( v ) + '</td>' ).join( '' ) + '</tr>'
			).join( '' ) + '</tbody></table></div>' +
				'<p class="mm-cmp-hint">Highlighted rows are where the cars differ. ' + ( cars.length < CMP_MAX ? '<a href="' + esc( cfg.shop ) + '">Add another car →</a>' : '' ) + '</p>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load the comparison. Please refresh the page.</p>';
		}
	}

	/* Copy the car's link ------------------------------------------------ */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-mm-copy]' );
		if ( ! b ) return;
		const url = b.dataset.mmCopy;
		try {
			await navigator.clipboard.writeText( url );
		} catch ( err ) {
			const t = document.createElement( 'textarea' );
			t.value = url;
			document.body.appendChild( t );
			t.select();
			document.execCommand( 'copy' );
			t.remove();
		}
		toast( '🔗 Link copied. Share it on WhatsApp or anywhere.' );
	} );

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-mm-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'mm-qv' );
		const body = dlg && dlg.querySelector( '[data-mm-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="mm-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.mmQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="mm-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-mm-qv-img="' + i + '"' + ( i ? '' : ' class="is-on"' ) + ' aria-label="Photo ' + ( i + 1 ) + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const spec = b.dataset.badge ? '<p class="mm-specline">' + b.dataset.badge.split( ' · ' ).map( ( s ) => '<span>' + esc( s ) + '</span>' ).join( '' ) + '</p>' : '';
			const price = money( p.prices.price, p.prices );
			const msg = enquiry( plain( p.name ), fmt( price ), b.dataset.stock, p.permalink );
			const from = p.is_in_stock && price ? '<p class="mm-from">From <strong>' + fmt( Math.ceil( monthly( price * ( 1 - cfg.minDep / 100 ), cfg.months, cfg.rate ) / 100 ) * 100 ) + '</strong>/mo with ' + cfg.minDep + '% down</p>' : '';
			body.innerHTML = '<div class="mm-qv__grid"><div class="mm-qv__media"><div class="mm-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="mm-qv__info"><div class="mm-chips"><span class="mm-chip mm-chip--ok">✓ Clean • Verified</span>' + ( b.dataset.stock ? '<span class="mm-chip mm-chip--id">Stock ID ' + esc( b.dataset.stock ) + '</span>' : '' ) + '</div><h2>' + p.name + '</h2>' + spec +
				'<div class="mm-qv__price">' + p.price_html + '</div>' + from +
				'<div class="mm-qv__desc">' + ( p.description || '' ) + '</div>' +
				'<div class="mm-qv__actions"><a class="wp-element-button" href="' + esc( p.permalink ) + '">' + ( p.is_in_stock ? 'View &amp; reserve' : 'See details' ) + '</a>' +
				'<a class="mm-wa-order" href="' + esc( waLink( msg ) ) + '" target="_blank" rel="noopener">' + waIcon + 'WhatsApp us</a></div></div></div>';
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this car. Please try again.</p>';
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-mm-qv-img]' );
		if ( ! t ) return;
		const media = t.closest( '.mm-qv__media' );
		media.querySelectorAll( '.mm-qv__main img' ).forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.mmQvImg ) ) );
		media.querySelectorAll( '[data-mm-qv-img]' ).forEach( ( x ) => x.classList.toggle( 'is-on', x === t ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.mm-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.mm-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'mm-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const items = await ( await fetch( cfg.api + 'search&q=' + encodeURIComponent( q ) ) ).json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.image ? '<img src="' + esc( p.image ) + '" alt="">' : '' ) + '<span>' + esc( p.name ) + '<small>' + ( p.badge ? esc( p.badge ) + ' · ' : '' ) + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>Nothing on the lot matches “' + esc( q ) + '”. <a href="' + esc( cfg.home ) + 'find-a-car/?like=' + encodeURIComponent( q ) + '#request">We can find it for you →</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Hero finder: cash budget or monthly budget ------------------------- */
	document.addEventListener( 'change', ( e ) => {
		const form = e.target.closest( '[data-mm-finder]' );
		if ( ! form || e.target.name !== 'pay' ) return;
		$$( '[data-mm-budget]', form ).forEach( ( el ) => ( el.hidden = el.dataset.mmBudget !== e.target.value ) );
	} );
	document.addEventListener( 'submit', ( e ) => {
		const form = e.target.closest( '[data-mm-finder]' );
		if ( ! form ) return;
		e.preventDefault();
		const make = form.make.value;
		const bodyOpt = form.body.selectedOptions[ 0 ];
		const pay = ( form.querySelector( 'input[name="pay"]:checked' ) || {} ).value;
		let max = form.max_price.value;
		// A monthly budget becomes the most a car can cost with the smallest deposit over the card term.
		if ( pay === 'monthly' ) {
			const m = Number( form.max_monthly.value );
			max = m ? Math.floor( m / monthly( 1, cfg.months, cfg.rate ) / ( 1 - cfg.minDep / 100 ) / 10000 ) * 10000 : '';
		}
		// A make has its own page; a body type alone has its category page; both together filter the make's page.
		const url = new URL( make || ( bodyOpt && bodyOpt.value ? bodyOpt.dataset.url : form.action ), window.location.href );
		if ( make && bodyOpt && bodyOpt.value ) url.searchParams.set( 'product_cat', bodyOpt.value );
		if ( max ) url.searchParams.set( 'max_price', max );
		if ( form.min_year.value ) url.searchParams.set( 'min_year', form.min_year.value );
		window.location = url.toString();
	} );

	/* Price slider ------------------------------------------------------- */
	function initPrice() {
		$$( '[data-mm-price]' ).forEach( ( form ) => {
			const [ lo, hi ] = $$( 'input[type="range"]', form );
			const out = form.querySelector( 'output' );
			const paint = ( moved ) => {
				// The two handles can't cross.
				if ( Number( lo.value ) > Number( hi.value ) ) {
					if ( moved === lo ) hi.value = lo.value;
					else lo.value = hi.value;
				}
				out.textContent = fmt( lo.value ) + ' – ' + fmt( hi.value );
			};
			lo.addEventListener( 'input', () => paint( lo ) );
			hi.addEventListener( 'input', () => paint( hi ) );
		} );
	}

	/* Finance calculator ------------------------------------------------- */
	function initFinance() {
		$$( '[data-mm-finance]' ).forEach( ( box ) => {
			const dep = box.querySelector( '[data-mm-fin-dep]' );
			const rateInput = box.querySelector( '[data-mm-fin-rate]' );
			const priceInput = box.querySelector( '[data-mm-fin-price]' );
			let price = Number( box.dataset.price ) || 0;
			let lastToast = '';
			const state = () => {
				const pct = Number( dep.value );
				const term = Number( ( box.querySelector( 'input[name="mm_term"]:checked' ) || {} ).value || 48 );
				const rate = Math.min( 40, Math.max( 0, Number( rateInput.value ) || Number( cfg.rate ) || 14 ) );
				const deposit = price * pct / 100;
				const loan = price - deposit;
				const m = monthly( loan, term, rate );
				return { pct, term, rate, deposit, loan, m, interest: m * term - loan };
			};
			const paint = () => {
				const s = state();
				box.querySelector( '[data-mm-fin-dep-pct]' ).textContent = s.pct + '%';
				box.querySelector( '[data-mm-fin-dep-ksh]' ).textContent = fmt( s.deposit ) + ' down';
				box.querySelector( '[data-mm-fin-monthly]' ).textContent = price ? fmt( s.m ) : '–';
				box.querySelector( '[data-mm-fin-loan]' ).textContent = price ? fmt( s.loan ) : '–';
				box.querySelector( '[data-mm-fin-interest]' ).textContent = price ? fmt( s.interest ) : '–';
				dep.style.setProperty( '--fill', ( ( s.pct - dep.min ) / ( dep.max - dep.min ) ) * 100 + '%' );
			};
			// One toast when someone settles on a figure, not on every slider step.
			const settled = () => {
				const s = state();
				const key = price + '|' + s.pct + '|' + s.term + '|' + s.rate;
				if ( ! price || key === lastToast ) return;
				lastToast = key;
				toast( 'Estimate: about <strong>' + fmt( s.m ) + '</strong> a month over ' + s.term + ' months' );
			};
			dep.addEventListener( 'input', paint );
			dep.addEventListener( 'change', settled );
			rateInput.addEventListener( 'input', paint );
			rateInput.addEventListener( 'change', settled );
			box.addEventListener( 'change', ( e ) => {
				if ( e.target.name === 'mm_term' ) {
					paint();
					settled();
				}
			} );
			if ( priceInput ) {
				priceInput.addEventListener( 'input', () => {
					price = Number( priceInput.value.replace( /\D/g, '' ) ) || 0;
					paint();
				} );
				priceInput.addEventListener( 'blur', () => {
					priceInput.value = price ? price.toLocaleString( 'en-KE' ) : '';
					settled();
				} );
			}
			const carName = () => {
				const title = document.querySelector( '.single-product .wp-block-post-title, .product_title' );
				return box.hasAttribute( 'data-on-car' ) && title ? title.textContent.trim() : '';
			};
			box.querySelector( '[data-mm-fin-wa]' ).addEventListener( 'click', () => {
				const s = state();
				const car = carName() ? 'the ' + carName() + ' (' + window.location.href.split( '?' )[ 0 ] + ')' : 'a car around ' + fmt( price );
				window.open( waLink( 'Hi Moti Moto-Rs, I\'d like to finance ' + car + '.\nPrice: ' + fmt( price ) + '\nDeposit: ' + s.pct + '% (' + fmt( s.deposit ) + ')\nTerm: ' + s.term + ' months\nEstimate: about ' + fmt( s.m ) + ' a month.\nCan you help me apply?' ), '_blank', 'noopener' );
			} );
			// Pre-approval pop-up, filled with this estimate.
			box.querySelector( '[data-mm-fin-apply]' ).addEventListener( 'click', () => {
				const dlg = document.getElementById( 'mm-fa' );
				if ( ! dlg || ! dlg.showModal ) return;
				const s = state();
				const form = dlg.querySelector( '[data-mm-request]' );
				resetForm( form );
				form.car.value = carName() || 'Not chosen yet';
				form.price.value = fmt( price );
				form.deposit.value = s.pct + '% (' + fmt( s.deposit ) + ')';
				form.term.value = s.term + ' months';
				form.monthly.value = 'about ' + fmt( s.m ) + ' a month at ' + s.rate + '%';
				dlg.querySelector( '[data-mm-fa-sum]' ).innerHTML = ( carName() ? '<strong>' + esc( carName() ) + '</strong><br>' : '' ) + esc( fmt( price ) ) + ', ' + s.pct + '% down, ' + s.term + ' months: about <strong>' + esc( fmt( s.m ) ) + '</strong> a month.';
				dlg.showModal();
			} );
			paint();
		} );
	}

	/* Requests: trade-in, car finder, test drive, finance ----------------- */
	// Dates: from tomorrow, never a Sunday.
	function initDates() {
		const t = new Date();
		t.setDate( t.getDate() + 1 );
		const min = t.toISOString().slice( 0, 10 );
		$$( '[data-mm-date]' ).forEach( ( input ) => {
			input.min = min;
			input.addEventListener( 'change', () => {
				const d = new Date( input.value + 'T12:00:00' );
				if ( input.value && d.getDay() === 0 ) {
					input.value = '';
					toast( 'Viewings run Monday to Saturday. Please pick another day.' );
				}
			} );
		} );
	}

	function showError( form, msg ) {
		const el = form.querySelector( '[data-mm-error]' );
		if ( ! el ) return toast( esc( msg ) );
		el.textContent = msg;
		el.hidden = ! msg;
	}
	// Required fields; focuses the first gap.
	function checkFields( form ) {
		for ( const f of $$( '[required]', form ) ) {
			const empty = f.type === 'radio' ? ! form.querySelector( 'input[name="' + f.name + '"]:checked' ) : ! String( f.value ).trim();
			if ( empty ) {
				const label = f.type === 'radio' ? ( f.closest( 'fieldset' ).querySelector( 'legend' ) || {} ).textContent : ( f.closest( 'label' ) || {} ).firstChild && f.closest( 'label' ).firstChild.textContent;
				showError( form, 'Please fill in: ' + String( label || 'the highlighted field' ).trim() );
				( f.type === 'radio' ? f.closest( 'fieldset' ) : f ).scrollIntoView( { behavior: 'smooth', block: 'center' } );
				if ( f.type !== 'radio' ) f.focus( { preventScroll: true } );
				return false;
			}
		}
		const phone = form.querySelector( 'input[name="phone"]' );
		if ( phone && phone.value && phone.value.replace( /\D/g, '' ).length < 9 ) {
			showError( form, 'Please check the phone number.' );
			phone.focus();
			return false;
		}
		showError( form, '' );
		return true;
	}
	// A fresh form each time a pop-up opens.
	function resetForm( form ) {
		$$( ':scope > *', form ).forEach( ( el ) => ( el.hidden = el.hasAttribute( 'data-mm-done' ) || el.hasAttribute( 'data-mm-error' ) ) );
	}

	async function sendRequest( form ) {
		const btn = form.querySelector( 'button[type="submit"]' );
		const data = Object.fromEntries( new FormData( form ) );
		data.type = form.dataset.mmRequest;
		btn.disabled = true;
		const label = btn.textContent;
		btn.textContent = 'Sending…';
		try {
			const res = await fetch( cfg.api + 'request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( data ) } );
			const out = await res.json();
			if ( ! res.ok ) throw new Error( out.message || 'Could not send. Please try again.' );
			const done = form.querySelector( '[data-mm-done]' );
			done.querySelector( '[data-mm-ref]' ).textContent = out.ref;
			done.querySelector( '[data-mm-done-wa]' ).href = out.wa;
			$$( ':scope > :not([data-mm-done])', form ).forEach( ( el ) => ( el.hidden = true ) );
			done.hidden = false;
			done.scrollIntoView( { behavior: 'smooth', block: 'center' } );
			toast( '✓ Sent. Your reference is <strong>' + esc( out.ref ) + '</strong>' );
		} catch ( err ) {
			showError( form, err.message );
		} finally {
			btn.disabled = false;
			btn.textContent = label;
		}
	}
	document.addEventListener( 'submit', ( e ) => {
		const form = e.target.closest( '[data-mm-request]' );
		if ( ! form ) return;
		e.preventDefault();
		if ( checkFields( form ) ) sendRequest( form );
	} );

	// Test drive pop-up, filled with the car it was opened from.
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-mm-testdrive]' );
		if ( ! b ) return;
		e.preventDefault();
		const dlg = document.getElementById( 'mm-td' );
		if ( ! dlg || ! dlg.showModal ) return;
		const form = dlg.querySelector( '[data-mm-request]' );
		resetForm( form );
		form.car.value = b.dataset.mmTestdrive;
		form.url.value = b.dataset.url || '';
		dlg.querySelector( '[data-mm-td-car]' ).textContent = b.dataset.mmTestdrive;
		dlg.showModal();
	} );

	// Trade-in estimator pop-up on a car page.
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-mm-tradein]' );
		if ( ! b ) return;
		const dlg = document.getElementById( 'mm-ti' );
		if ( ! dlg || ! dlg.showModal ) return;
		const form = dlg.querySelector( '[data-mm-request]' );
		resetForm( form );
		form.want.value = b.dataset.mmTradein + ' (' + fmt( b.dataset.price ) + ')';
		dlg.querySelector( '[data-mm-ti-car]' ).textContent = b.dataset.mmTradein;
		dlg.showModal();
	} );

	function init() {
		paintLists();
		renderWishlist();
		renderCompare();
		initSearch();
		initPrice();
		initFinance();
		initDates();
		// Cards re-render client-side in some blocks; keep hearts and compare buttons in sync.
		new MutationObserver( () => paintLists() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
